from PIL import Image

img = Image.open("received_file_1.jpeg")
img.show()