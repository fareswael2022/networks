from socket import *
import struct
import random
import time

def read_img(path):
    with open(path, 'rb') as file:
        img = file.read()
    return img

def divide_img(img, file_id, packet_id, HeaderSize):
    packets = []
    chunk_size = MSS - HeaderSize
    for i in range(0, len(img), chunk_size):
        packet_data = img[i:i + chunk_size]
        if i + chunk_size >= len(img):
            trailer = 0xFFFFFFFF
        else:
            trailer = 0x00000000
        packet = struct.pack(f"!HH{len(packet_data)}sI", packet_id, file_id, packet_data, trailer)
        packets.append(packet)
        packet_id += 1
    return packets

HEADER_SIZE = 8
MSS = 1024
N = 5
TIMEOUT = 2
LOSS_RATE = 0.1

receiver_ip = '127.0.0.1'
receiver_port = 5200

image_paths = [
    'E:\\Downloads\\small file.jpeg',
    'E:\\Downloads\\medium file.jpeg',
    'E:\\Downloads\\large file.jpeg'
]

files = [(idx + 1, path) for idx, path in enumerate(image_paths)]

def send_file(img_id, img_path):
    img = read_img(img_path)
    packets = divide_img(img, img_id, 0, HEADER_SIZE)
    total_packets = len(packets)
    print(f"Total packets: {total_packets}")
    total_bytes = len(img)
    print(f"Total bytes: {total_bytes}")

    with socket(AF_INET, SOCK_DGRAM) as sender:
        sender.sendto(struct.pack("!H", total_packets), (receiver_ip, receiver_port))
        sender.settimeout(TIMEOUT)
        base = 0
        next_seq_num = 0
        retransmissions = 0

        start_time = time.time()

        while base < total_packets:
            while next_seq_num < min(base + N, total_packets):
                packet = packets[next_seq_num]
                current_time = time.time() - start_time
                if random.random() > LOSS_RATE:
                    sender.sendto(packet, (receiver_ip, receiver_port))
                    print(f"[{current_time:.4f}] Sent packet {next_seq_num + 1}")
                else:
                    print(f"[{current_time:.4f}] Packet {next_seq_num + 1} lost.")
                    retransmissions += 1
                next_seq_num += 1

            try:
                while True:
                    ack, _ = sender.recvfrom(1024)
                    if len(ack) < 4:
                        print("Received an incomplete ACK packet")
                        continue
                    ack_packet_id, _ = struct.unpack("!HH", ack[:4])
                    if ack_packet_id >= base:
                        base = ack_packet_id + 1
                        break
            except timeout:
                print("Timeout, resending unacknowledged packets")
                next_seq_num = base
                for seq_num in range(base, min(base + N, total_packets)):
                    packet = packets[seq_num]
                    current_time = time.time() - start_time
                    sender.sendto(packet, (receiver_ip, receiver_port))
                    print(f"[{current_time:.4f}] Retransmitted packet {seq_num + 1}")
                    retransmissions += 1

        end_time = time.time()
        elapsed_time = end_time - start_time

        average_transfer_rate_bytes = total_bytes / elapsed_time
        average_transfer_rate_packets = total_packets / elapsed_time
        print()
        print("File transfer information:")
        print(f"Start time: {start_time}")
        print(f"End time: {end_time}")
        print(f"Elapsed time: {elapsed_time} seconds")
        print(f"Number of packets: {total_packets}")
        print(f"Number of bytes: {total_bytes}")
        print(f"Number of retransmissions (sender): {retransmissions}")
        print(f"Average transfer rate (bytes/sec): {average_transfer_rate_bytes}")
        print(f"Average transfer rate (packets/sec): {average_transfer_rate_packets}")

        print("All packets sent and acknowledged. Sender terminated.")

for img_id, img_path in files:
    input(f"Press Enter to start transferring file {img_id}")
    send_file(img_id, img_path)
    print(f"Finished transferring file {img_id}\n")



















